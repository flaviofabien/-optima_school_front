export type ErrorServerForm = {
    response : {
        data : {
            message : string
        }
    }
}