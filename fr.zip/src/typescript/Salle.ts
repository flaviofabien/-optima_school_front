export type EcoleType = {
    data : {
        nom: string;
        idEcole: number;
    }[]
}