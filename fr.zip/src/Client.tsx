
type Props = {}

export default function ClientPage({}: Props) {
  return (
    <div>ClientPage</div>
  )
}