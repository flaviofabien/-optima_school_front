
// //Render Server
// export const IP = "https://optima-school-backend.onrender.com/api";
// export const IPLocal = "https://optima-school-backend.onrender.com";

// Host render 
// export const IP = "http://dpg-d3167dmmcj7s7383dlk0-a:5000/api";
// export const IPLocal = "http://dpg-d3167dmmcj7s7383dlk0-a:5000";

// local
export const IP = "http://localhost:5000/api";
export const IPLocal = "http://localhost:5000";