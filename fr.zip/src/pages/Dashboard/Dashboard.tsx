import Header from "../../Components/header/Header";
import TextHeaderTable from "../../Components/ui/Text/TextinTable";
import { getAllStates } from "../../api/State";
import { useQuery } from "@tanstack/react-query";
import { useSelector } from "react-redux";
import type { RootState } from "../../store/store";
import Loading from "../../Components/ui/Loader/Loading";
import AdminDashboard from "./AdminDashboard";
import ElevesDashBoard from "./ElevesDashBoard";


export default function Dashboard() {
const token = useSelector((state: RootState) => state.dataStorage.token);
const user = useSelector((state: RootState) => state.dataStorage.user);

  const { data, isLoading, isError } = useQuery<any>({
    queryKey: ["state", token],
    queryFn: () => getAllStates(token!),
  });
console.log(data);

  if (isLoading) {
    return <Loading />;
  }
  if (isError) {
    return <div>Error</div>;
  }

  return (
    <div className="bg-[var(--font)] h-screen">
        <Header />
        <div className="mt-4 flex justify-between px-8 lg:pl-64 items-center">
            <div className="w-full ">
                <TextHeaderTable text="Les Statistique" />
                {user.role === "admin" &&   <AdminDashboard data={data} />}
                {user.role === "eleve" &&  <ElevesDashBoard  data={data} />}
               
            </div>
            
        </div>
   
    </div>
  )
}