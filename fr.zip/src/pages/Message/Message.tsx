import Header from "../../Components/header/Header";
import TextHeaderTable from "../../Components/ui/Text/TextinTable";
import { useSelector } from "react-redux";
import type { RootState } from "../../store/store";
// import { socket } from "../../main";
import { useEffect, useState } from "react";


export default function Message() {
  const [message,setMessage] = useState("");
  const token = useSelector((state: RootState) => state.dataStorage.token);
  const user = useSelector((state: RootState) => state.dataStorage.user);
  const [messages, setMessages] = useState([]);

    useEffect(() => {
      // // user connected
      // socket.emit("register", { userId : user.id });

      // // private message
      // socket.on("private_message", (data) => {
      //     setMessages((prev) => [...prev, data]);
      // });

      // // Nettoyage
      // return () => {
      //   socket.off("private_message");
      // };
    }, [user]);

    const sendMessage = () => {
      // socket.emit("send_message" , { toUserId : 11 , message})

      // setMessages((prev) => [...prev, { fromUserId: user.id, message }]);
      // setMessage("");
    }

  return (
    <div className="bg-[var(--font)] h-screen">
        <Header />
        <div className="mt-4 flex justify-between px-8 lg:pl-64 items-center">
            <div className="w-full ">
                <TextHeaderTable text="Messages" />
                <div className="w-full flex justify-between gap-20 mt-4 border-2 border-gray-400">
                    <input type="text" value={message} onChange={(e) =>  setMessage(e.target.value)} />
                    <button onClick={ sendMessage} className="bg-blue-500 px-4 py-2 rounded-md"> Connect </button> 
                </div>
                
          <div className="mt-6 max-h-80 overflow-y-auto border p-4 bg-white rounded-md">
            <h3 className="font-bold mb-2">Messages reçus :</h3>
            {messages.length === 0 && <p>Aucun message pour le moment.</p>}

            <ul>
              {/* {messages.map((msg, idx) => (
                <li
                  key={idx}
                  className={`mb-2 p-2 rounded ${
                    msg.fromUserId === user.id ? "bg-blue-200 text-right" : "bg-gray-200 text-left"
                  }`}
                >
                  <span>
                    {msg.fromUserId === user.id ? "Moi" : `User ${msg.fromUserId}`} : {msg.message}
                  </span>
                </li>
              ))} */}
            </ul>
          </div>
       

            </div>
        </div> 
    </div>
  )
}